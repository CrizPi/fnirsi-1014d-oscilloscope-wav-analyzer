import numpy as np

def get_scope_fs(ch1, config):
    time = None
    N = len(ch1)
    time_div_s = config["time_div"] * config["time_multiplier"]
    T_total = 35 * time_div_s
    fs = N / T_total
    time = np.arange(N) / fs

    return time, fs


def convert_scope_data(ch1, ch2, config, measures):

    channels = [ch1, ch2]
    ch_real = []

    for ch in range(2):

        raw = np.array(channels[ch], dtype=float)

        raw_min = raw.min()
        raw_max = raw.max()

        vpp = measures["Vpp"][ch]
        vmin = measures["Vmin"][ch]

        scale = vpp / (raw_max - raw_min)

        volts = (raw - raw_min) * scale + vmin

        volts = volts * config["probe"][ch]

        ch_real.append(volts)

    return ch_real[0], ch_real[1]


def get_frequency(signal, fs):

    signal = signal - np.mean(signal)

    crossings = np.where((signal[:-1] < 0) & (signal[1:] >= 0))[0]

    if len(crossings) < 2:
        return 0

    periods = np.diff(crossings) / fs

    T = np.mean(periods)

    freq = 1 / T

    return freq